# MC Grid Env
This is an implementation of a grid world I-Maze environment based on observation images from malmo minecraft environment. It might be extended in the future to make the grid more configurable (flexible to meet different grid environment needs, other than just the current/fixed I-Maze).
 parents master