from setuptools import setup, find_packages

setup(name='mcgridenv',
      version='0.0.1',
      install_requires=['gym', 'numpy'],
      packages=find_packages(),
      author="Ese Ben-Iwhiwhu",
      author_email="e.ben-iwhiwhu@lboro.ac.uk",
      description="This is an implementation of a grid world I-Maze environment based on observation images from malmo minecraft environment.",
      license="Copyright (c) 2019 Ese Ben-Iwhiwhu. MIT License",
      keywords="Deep reinforcement learning, dynamic goals/rewards, meta learning, adaptation, partially observable Markov decision problems, POMDP",
      url="",
      project_urls={
        "Bug Tracker": "",
        "Documentation": "",
        "Source Code": "",
    }
)
