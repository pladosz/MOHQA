# -*- coding: utf-8 -*-
import numpy as np
from gym import Env
from gym.spaces import Box
from gym.spaces import Discrete

class Grid(Env):
	NORTH = 0
	EAST = 1
	SOUTH = 2
	WEST = 3
	ACTION_FORWARD = 0
	ACTION_BACKWARD = 1
	ACTION_RIGHT_TURN = 2
	ACTION_LEFT_TURN = 3

	GRID_SAFE = 1 # safe path that agent can traverse through
	GRID_UNSAFE = 0 # e.g. lava, thus leads to agent death

	def __init__(self, max_num_turns=None):
		super(Grid, self).__init__()
		
		obs_shape = (32, 32) # TODO fix hardcode
		discrete_action_dim = 4 # TODO fix hardcode
		self.observation_space = Box(low=-np.inf, high=np.inf, shape=obs_shape)
		self.action_space = Discrete(discrete_action_dim)
		self.valid_actions = list(range(self.action_space.n))

		self.max_turns = max_num_turns
		ret = self._build_env()
		# numpy array representing the grid environment
		self.grid = ret[0]
		# goals. 2D numpy tensor of shape (N, 2) representing goal locations
		# each row is an x, y co-ordinate goal location
		self.goals = ret[1] 
		# current goal. x, y co-ordinate numpy vector. will be initially set in reset_goal
		self.goal = None
		# dictionary, with position tuple as key and value as a list of 4 numpy array, 
		# each representing the observation view for each orientation
		self.assets = ret[2] 
		# asset for crash screen (i.e. dead agent)
		self.crash_asset = ret[3]
		# x, y co-ordinate numpy vector. will be initially set in reset
		self.position = None
		# direction agent is facing North, East, South, West. will be initally set by reset
		self.orientation = None 
		# number of turns the agent has made. will be initally set by reset
		self.num_turns = None
		# useful flag for env to request termination of an episode (e.g. when
		# `max_turns` have been completely used by agent). will be initally set by reset
		self.terminate = None
		# others. will be initially set by reset
		self.in_candidate_goal = None
		self.crash = None

		self.reset_goal()
	
	def step(self, action):
		if action not in self.valid_actions:
			raise ValueError('Action can only take values {0}'.format(self.valid_actions))

		crash = False
		if self.in_candidate_goal is False:
			if action == Grid.ACTION_FORWARD:
				if self.orientation == Grid.NORTH: self.position[0] -= 1
				elif self.orientation == Grid.SOUTH: self.position[0] += 1
				elif self.orientation == Grid.EAST: self.position[1] += 1
				else: self.position[1] -= 1
			elif action == Grid.ACTION_BACKWARD:
				if self.orientation == Grid.NORTH: self.position[0] += 1
				elif self.orientation == Grid.SOUTH: self.position[0] -= 1
				elif self.orientation == Grid.EAST: self.position[1] -= 1
				else: self.position[1] += 1
			else:
				if self.max_turns is None or self.num_turns < self.max_turns:
					num_orientation = 4 # NORTH, EAST, SOUTH, WEST
					if action == Grid.ACTION_LEFT_TURN: self.orientation -= 1
					else: self.orientation += 1
					self.orientation = self.orientation % num_orientation
					self.num_turns += 1
				else:
					self.terminate = True
			# check if agent has gone out of safe zone (i.e. fell into lava)
			if self.grid[self.position[0], self.position[1]] == Grid.GRID_UNSAFE: 
				crash = True

		self.crash = crash
		obs = self._get_obs(crash=crash)
		reward = self._get_reward()
		done = self._get_done()
		info = {}
		# when agent is in a candidate location, one random action is still
		# required before episode terminates
		for i in np.arange(len(self.goals)):
			if tuple(self.position) == tuple(self.goals[i]): self.in_candidate_goal = True

		if done is True: self.reset()

		return obs, reward, done, info 
	
	def reset(self):
		# reset position
		self.position = np.array([4, 3])
		# reset orientation
		self.orientation = Grid.SOUTH
		# reset crash
		self.crash = False
		# reset terminate
		self.terminate = False
		# reset candidate_goal
		self.in_candidate_goal = False
		# reset turns
		self.num_turns = 0

		obs = self._get_obs()
		reward = 0.
		done = False
		info = {}
		return obs, reward, done, info 
	
	def reset_goal(self, goal=None):
		if goal is None:
			# generate a random goal
			num_goals = len(self.goals)
			goal_idx = np.random.randint(low=0, high=num_goals)
			goal = self.goals[goal_idx]
		self.set_goal(goal)
		return self.reset()
	
	def render(self, mode='human'):
		raise NotImplementedError

	def close(self):
		raise NotImplementedError

	def seed(self, seed):
		np.random.seed(seed)

	def set_goal(self, goal):
		if goal not in self.goals:
			raise ValueError('Inccorect `goal` passed as argument')
		self.goal = goal
	
	def get_goal(self):
		return self.goal
	
	def get_goals(self):
		return self.goals
	
	def _get_obs(self, crash=False):
		if crash == True:
			return self.crash_asset
		# use current position and orientation to get observation
		return self.assets[tuple(self.position)][self.orientation]
	
	def _get_reward(self):
		# if agent crashed (e.g. died in lava) return negative rweard
		if self.crash is True: return -1.
		if self.in_candidate_goal:
			# use current position to determine reward
			if tuple(self.position) == tuple(self.goal): return 1.
		return 0.
	
	def _get_done(self):
		# if agent crashed (e.g. died in lava) return True
		if self.crash is True: return True
		elif self.terminate is True: return True
		elif self.in_candidate_goal: return True
		else: return False

	def _build_env(self):
		# I-maze grid
		# 0, 0, 0, 0, 0, 0, 0
		# 0, 0, 0, 0, 0, 0, 0
		# 1, 1, 1, 1, 1, 1, 1
		# 0, 0, 0, 1, 0, 0, 0
		# 0, 0, 0, 1, 0, 0, 0
		# 0, 0, 0, 1, 0, 0, 0
		# 1, 1, 1, 1, 1, 1, 1
		# 0, 0, 0, 0, 0, 0, 0
		# 0, 0, 0, 0, 0, 0, 0
		grid = np.zeros((9, 7), dtype=np.uint8) # TODO: fix this hard coding
		grid[2, : ] = 1
		grid[6, : ] = 1
		grid[2 : 7, 3] = 1

		# all candidate goal locations
		goals = np.array([[2, 0], [2, 6], [6, 0], [6, 6]])

		# observation assets
		assets = {}
		assets[(2, 0)] = ['2_0_N', '2_0_E', '2_0_S', '2_0_W']
		assets[(2, 1)] = ['2_1_N', '2_1_E', '2_1_S', '2_1_W']
		assets[(2, 2)] = ['2_2_N', '2_2_E', '2_2_S', '2_2_W']
		assets[(2, 3)] = ['2_3_N', '2_3_E', '2_3_S', '2_3_W']
		assets[(2, 4)] = ['2_4_N', '2_4_E', '2_4_S', '2_4_W']
		assets[(2, 5)] = ['2_5_N', '2_5_E', '2_5_S', '2_5_W']
		assets[(2, 6)] = ['2_6_N', '2_6_E', '2_6_S', '2_6_W']

		assets[(6, 0)] = ['6_0_N', '6_0_E', '6_0_S', '6_0_W']
		assets[(6, 1)] = ['6_1_N', '6_1_E', '6_1_S', '6_1_W']
		assets[(6, 2)] = ['6_2_N', '6_2_E', '6_2_S', '6_2_W']
		assets[(6, 3)] = ['6_3_N', '6_3_E', '6_3_S', '6_3_W']
		assets[(6, 4)] = ['6_4_N', '6_4_E', '6_4_S', '6_4_W']
		assets[(6, 5)] = ['6_5_N', '6_5_E', '6_5_S', '6_5_W']
		assets[(6, 6)] = ['6_6_N', '6_6_E', '6_6_S', '6_6_W']

		assets[(3, 3)] = ['3_3_N', '3_3_E', '3_3_S', '3_3_W']
		assets[(4, 3)] = ['4_3_N', '4_3_E', '4_3_S', '4_3_W']
		assets[(5, 3)] = ['5_3_N', '5_3_E', '5_3_S', '5_3_W']

		crash_asset = 'crash'

		return grid, goals, assets, crash_asset


if __name__ == '__main__':
	env = Grid(max_num_turns=3)
	obs, reward, done, info  = env.reset()

	while not done:
		print('obs: ', obs)
		action = int(input('action (0, 1, 2, or 3): '))
		next_obs, reward, done, info = env.step(action)
		print('reward: ', reward)
		print('done: ', done)
		print('info: ', info)
		print('next obs: ', next_obs)
		print('-----')
		obs = next_obs
