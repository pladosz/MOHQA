# ------------------------------------------------------------------------------------------------
# Copyright (c) 2018 Microsoft Corporation
# 
# Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
# associated documentation files (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge, publish, distribute,
# sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included in all copies or
# substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
# NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
# DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
# ------------------------------------------------------------------------------------------------


'''
Script to generate assets (image observations) based on supplied xml env in malmo minecraft
'''

import malmoenv
import argparse
from pathlib import Path
import time
from PIL import Image
import numpy as np
import os
import lxml.etree as etree


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='malmovnv test')
    parser.add_argument('--mission', type=str, default='mission.xml', help='the mission xml')
    parser.add_argument('--port', type=int, default=9000, help='the mission server port')
    parser.add_argument('--server', type=str, default='127.0.0.1', help='mission server DNS or IP')
    parser.add_argument('--episode', type=int, default=0, help='the start episode - default is 0')
    parser.add_argument('--role', type=int, default=0, help='the agent role - defaults to 0')
    parser.add_argument('--resync', type=int, default=0, help='exit and re-sync every N resets'
                                                              ' - default is 0 meaning never.')
    parser.add_argument('--experimentUniqueId', type=str, default='test1', help="experiment's id.")
    args = parser.parse_args()

    xml = Path(args.mission).read_text()
    env = malmoenv.make()
    env.init(xml, args.port,
             server=args.server,
             server2=args.server, port2=None,
             role=args.role,
             exp_uid=args.experimentUniqueId,
             episode=args.episode, resync=args.resync)
    # get xml element (from mission spec) used to specify goal location
    xml = env.xml
    namespace='http://ProjectMalmo.microsoft.com'
    path_ = '/ns:MissionInit/ns:Mission/ns:ServerSection/'\
        'ns:ServerHandlers/ns:DrawingDecorator'
    ret = xml.xpath(path_, namespaces={'ns': namespace})
    assert len(ret) == 1, 'incorrect xml specification for the mission'
    ret = ret[0]
    xml_goalelem = None
    for element in ret: #access the children of <DrawingDecorator> 
        if element.tag is etree.Comment: continue
        if element.attrib['type'] == 'cyan_shulker_box':
            xml_goalelem = element
            break
    msg_ = 'could not retrieve the element in the mission spec that will be used to specify goal '\
        'location. Please make sure that the type attribute in this element matches what is '\
        'specified in `args.mc_goalblock`.'
    assert xml_goalelem is not None, msg_
	# get xml element (from mission spec) used to specify agent start position
    xml = env.xml
    namespace='http://ProjectMalmo.microsoft.com'
    path_ = '/ns:MissionInit/ns:Mission/ns:AgentSection/'\
        'ns:AgentStart/ns:Placement'
    ret = xml.xpath(path_, namespaces={'ns': namespace})
    assert len(ret) == 1, 'incorrect xml specification for the mission'
    ret = ret[0]
    xml_agentpos = ret
    # goals (south as orientation of reference)
    goals = {}
    goals['right_left'] = ['1', '46', '8', '1', '46', '8']
    goals['left_right'] = ['9', '46', '8', '9', '46', '8']
    goals['right_right'] = ['1', '46', '0', '1', '46', '0']
    goals['left_left'] = ['9', '46', '0', '9', '46', '0']
    # agent start placement
    placements = {}
	# home + home corridor
    placements['0_5'] = ['5.5', '47.0', '0.5']
    placements['1_5'] = ['5.5', '47.0', '1.5']
    placements['2_5'] = ['5.5', '47.0', '2.5']
    placements['3_5'] = ['5.5', '47.0', '3.5']

	# first decision point + horizontal corridor
    placements['4_2'] = ['2.5', '47.0', '4.5']
    placements['4_3'] = ['3.5', '47.0', '4.5']
    placements['4_4'] = ['4.5', '47.0', '4.5']
    placements['4_5'] = ['5.5', '47.0', '4.5']
    placements['4_6'] = ['6.5', '47.0', '4.5']
    placements['4_7'] = ['7.5', '47.0', '4.5']
    placements['4_8'] = ['8.5', '47.0', '4.5']

	# second decision point + vertical corridor
    placements['0_1'] = ['1.5', '47.0', '0.5']
    placements['1_1'] = ['1.5', '47.0', '1.5']
    placements['2_1'] = ['1.5', '47.0', '2.5']
    placements['3_1'] = ['1.5', '47.0', '3.5']
    placements['4_1'] = ['1.5', '47.0', '4.5']
    placements['5_1'] = ['1.5', '47.0', '5.5']
    placements['6_1'] = ['1.5', '47.0', '6.5']
    placements['7_1'] = ['1.5', '47.0', '7.5']
    placements['8_1'] = ['1.5', '47.0', '8.5']

	# second decision point (other end) + vertical corridor
    placements['0_9'] = ['9.5', '47.0', '0.5']
    placements['1_9'] = ['9.5', '47.0', '1.5']
    placements['2_9'] = ['9.5', '47.0', '2.5']
    placements['3_9'] = ['9.5', '47.0', '3.5']
    placements['4_9'] = ['9.5', '47.0', '4.5']
    placements['5_9'] = ['9.5', '47.0', '5.5']
    placements['6_9'] = ['9.5', '47.0', '6.5']
    placements['7_9'] = ['9.5', '47.0', '7.5']
    placements['8_9'] = ['9.5', '47.0', '8.5']

    # orientation
    orientation = ['S', 'W', 'N', 'E']
    # print action space
    print(env.action_space.actions)

    h, w, d = env.observation_space.shape
    for goal_key, goal_value in goals.items():
        # set goal loaction
        xml_goalelem.attrib['x1'] = goal_value[0]
        xml_goalelem.attrib['y1'] = goal_value[1]
        xml_goalelem.attrib['z1'] = goal_value[2]
        xml_goalelem.attrib['x2'] = goal_value[3]
        xml_goalelem.attrib['y2'] = goal_value[4]
        xml_goalelem.attrib['z2'] = goal_value[5]
        # create asset directory
        dirpath = './assets_maze_depth2v3/{0}/'.format(goal_key)
        if not os.path.exists(dirpath):
            os.makedirs(dirpath)
        for placement_key, placement_value in placements.items():
            # set agent start loaction
            xml_agentpos.attrib['x'] = placement_value[0]
            xml_agentpos.attrib['y'] = placement_value[1]
            xml_agentpos.attrib['z'] = placement_value[2]
            # reset
            obs = env.reset()
            #filepath = '{0}{1}_{2}{3}.png'.format(dirpath, placement_key, orientation[0], 0)
            filepath = '{0}{1}_{2}.png'.format(dirpath, placement_key, orientation[0])
            img = Image.fromarray(np.flipud(obs.reshape((h, w, d))))
            img.save(filepath)
            #for i in range(4):
            for i in range(1, 4):
                action = 2 # right turn
                obs, reward, done, info = env.step(action)
                #idx = (i + 1) % 4
                #filepath = '{0}{1}_{2}{3}.png'.format(dirpath, placement_key, orientation[idx], i+1)
                filepath = '{0}{1}_{2}.png'.format(dirpath, placement_key, orientation[i])
                img = Image.fromarray(np.flipud(obs.reshape((h, w, d))))
                img.save(filepath)
                time.sleep(.05)

    env.close()
