# -*- coding: utf-8 -*-

from .imaze.imaze import IMazeGrid
from .mazed1v1.mazed1v1 import MazeDepth1v1Grid
from .mazed1v2.mazed1v2 import MazeDepth1v2Grid
from .mazed2v1.mazed2v1 import MazeDepth2v1Grid
from .mazed2v2.mazed2v2 import MazeDepth2v2Grid
from .mazed2v3.mazed2v3 import MazeDepth2v3Grid
from .mazed2v4.mazed2v4 import MazeDepth2v4Grid
from .mazed2v5.mazed2v5 import MazeDepth2v5Grid
from .mazed2v9.mazed2v9 import MazeDepth2v9Grid
